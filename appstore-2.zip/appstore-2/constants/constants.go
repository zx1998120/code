package constants

const (
    APP_INDEX = "app"
    USER_INDEX = "user"
    ES_URL = "http://10.150.0.2:9200"
    ES_USERNAME = "xin"
    ES_PASSWORD = "123456"
    STRIPE_API_KEY = "sk_test_51P87X7RoTXhlyeRli8YjyWdzlEShgaOV4WkHMtkWl2AvWVrMnF7nrhWh9O9f7PYChs5iVL8S46X54aTPc7yBQEcu00yqyIYOTi"
    GCS_BUCKET = "appstore2024"
)